# COMP.SE.110 — Group assignment repository

This repository is meant for storing your work regarding the group assignment in the Software Design course.

Modify this file as appropriate for your group assignment.

# UI Prototype (mid-term submission)
https://www.figma.com/proto/cmi0Yay8qHmh6Sjc6GWsAh/UI-Prototype?node-id=0-1&t=cM6LEhqL8GNcgxDk-1

# Mid-term submission
Running the application, Visual Studio Code
Executed files: createdFiles.lst, inputFiles.lst
To run the full application, build and run the whole demo in Visual Studio Code.

# Final Submission
Instructions for running the application can be found from the demo directory.