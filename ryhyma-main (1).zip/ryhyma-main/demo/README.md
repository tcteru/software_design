# Application for viewing correlation of weather and economy

The application uses JavaFX library. It can be run with the command `mvn clean javafx:run` on the root directory (where `pom.xml` is located).
